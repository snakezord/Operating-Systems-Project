#if !defined(_CONTROL_TOWER_H_)
#define _CONTROL_TOWER_H_
#include "shared.h"

typedef struct runway_t{
    int TYPE;
    int runway;
    int occupied;
}runway_t;



void control_tower();


#endif