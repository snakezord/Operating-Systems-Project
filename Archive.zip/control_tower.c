#include "shared.h"

void control_tower(){
    int slot_pos;
    slots_struct slot;
    control_tower_msg_t msg;
    signal(SIGINT, SIG_IGN);
    signal(SIGUSR1, show_stats);
    logger("Control Tower - Central Process Created\n");
    while(!TERMINATE){
        if(msgrcv(msqid,&msg,sizeof(msg),-1,0) < 0){
            logger("Error receiving messagem from message queue.\n");
            exit(0); 
        }
        if(msg.mtype == ARRIVAL || msg.mtype == PRIORITY){
            int fuel = msg.fuel;
            int eta =  msg.eta;            
            //A Torre de Controlo responderá pela mesma MSQ com o
            //número do slot em memória partilhada atribuído a esse voo específico. Será
            //através desse slot que as threads receberão a indicação de descolagem/aterragem,
            //bem como das informações de necessidade de uma manobra de holding ou de
            //desvio para outro aeroporto

            //Caso qualquer voo receba como resposta da Torre de
            //Controlo que o pedido de descolagem/aterragem foi rejeitado, 
            //a thread deverá terminar.

            slot_pos = get_empty_slot();
            slot.type = ARRIVAL;
            
            
            //sharedMemoryFlight_CT->slots[slot_pos] = slot;

            msg.slot = slot_pos;
            msg.mtype = ARRIVAL;

            //A Torre de Controlo deverá marcar voos prioritários como urgentes e evitar que 
            //eles tenham de efetuar manobras de holding. A thread deverá escrever no log 
            //o instante em que enviou a mensagem de emergência
            if(msg.priority==1){
                   
            }

            if(msgsnd(msqid,&msg,sizeof(msg),0) < 0){
                printf("Error sending message through message queue (%s).\n",strerror(errno));
                exit(0);
            }


            for(int i=0;i<4;i++){
                if(RUNWAYS[i].TYPE  == ARRIVAL  && RUNWAYS[i].occupied==0) {
                    if(fuel == 0){
                        sharedMemoryFlight_CT->slots[slot_pos].detour = 1;
                        break;
                    }else{
                        sharedMemoryFlight_CT->slots[slot_pos].landing  = 1;
                        RUNWAYS[i].occupied = 1;
                        break;
                    }
                }
            } 
            
            //printf("fuel: %d\neta: %d\npriority: %d\n",fuel, time_to_runway,msg.priority);
        }
        if(msg.mtype == DEPARTURE){
            int takeoff = msg.takeoff;
            slot_pos = get_empty_slot();
            slot.type = DEPARTURE;
            
            //Verify of depart

            sharedMemoryFlight_CT->slots[slot_pos] = slot; 
            msg.slot = slot_pos;
            msg.mtype = ARRIVAL;
            if(msgsnd(msqid,&msg,sizeof(msg),0) < 0){
                printf("Error sending message through message queue (%s).\n",strerror(errno));
                exit(0);
            }
        }
        

    }
}

