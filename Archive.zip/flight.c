#include "shared.h"



void * flight_arrival(void*arg){
    pthread_mutex_lock(&flight_arrival_mutex);
    flight_arrival_t * arrival = (flight_arrival_t*)arg;
    //deve arrancar apenas no instante init correspondente
    msleep(arrival->init);
    //Os voos de chegada devem notificar a Torre de Controlo através da fila de
    //mensagens o seu tempo até à pista (ETA) e o seu combustível.
    control_tower_msg_t msg;
    msg.mtype = ARRIVAL;
    msg.eta = arrival->eta;
    msg.fuel = arrival->fuel;
    msg.priority = 0;
    //Caso um voo de chegada apenas tenha combustível para voar até ao instante ‘4 +
    //ETA + duração da aterragem’, a mensagem a enviar à Torre de Controlo através
    //da fila de mensagens deve ser prioritária e lida antes das outras.
    if(arrival->fuel <= 4+(arrival->eta)+settings.landing_duration){
        msg.mtype = PRIORITY;
        msg.priority = 1;
    }
    if(msgsnd(msqid,&msg,sizeof(msg),0) < 0){
        printf("Error sending message through message queue (%s).\n",strerror(errno));
        exit(0);
    }
    if(msgrcv(msqid,&msg,sizeof(msg),ARRIVAL,0) < 0){
            logger("Error receiving messagem from message queue.\n");
            exit(0); 
    }
    // Falta aqui
    int slot = msg.slot;
    while(sharedMemoryFlight_CT->slots[slot].holding){
        pthread_cond_wait(&condition,&flight_arrival_mutex);
    }
    if(sharedMemoryFlight_CT->slots[slot].landing){
        msleep(arrival->eta);
        msleep(settings.landing_duration);
        sharedMemoryFlight_CT->slots[slot].landing = 0;
    }
    if(sharedMemoryFlight_CT->slots[slot].detour){
        sharedMemoryFlight_CT->slots[slot].detour =0;
    }
    pthread_join(arrival->thread,NULL);
    pthread_mutex_unlock(&flight_arrival_mutex);
    return 0;
}

void * flight_departure(void*arg){
    
    pthread_mutex_lock(&flight_departure_mutex);
    flight_departure_t * departure = (flight_departure_t*)arg;
    //deve arrancar apenas no instante init correspondente
    msleep(departure->init);
    //Os voos de partida, ao serem criados, devem enviar uma mensagem à Torre de
    //Controlo, através da MSQ a dizer qual é o seu instante de partida desejado.
    control_tower_msg_t msg;
    msg.mtype = DEPARTURE;
    msg.takeoff = departure->takeoff;
    msg.priority = 0;
    if(msgsnd(msqid,&msg,sizeof(msg),0) < 0){
        printf("Error sending message through message queue (%s).\n",strerror(errno));
        exit(0);
    }

    if(msgrcv(msqid,&msg,sizeof(msg),DEPARTURE,0) < 0){
            logger("Error receiving messagem from message queue.\n");
            exit(0); 
    }

    // Falta aqui 

    pthread_mutex_unlock(&flight_departure_mutex);
    return 0;
}